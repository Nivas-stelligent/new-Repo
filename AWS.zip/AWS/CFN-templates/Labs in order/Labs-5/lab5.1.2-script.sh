#!/bin/bash

stack="test-EC2-stack"

aws cloudformation create-stack --stack-name $stack --template-body file://lab5.1.2-ec2-template.yaml

aws cloudformation wait stack-create-complete --stack-name $stack