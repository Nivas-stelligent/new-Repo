#!/bin/bash
# Read the regions from the JSON file and store them in an array
regions=($(jq -r '.regions[]' labs1.3.1-regions.json))
# Loop through the regions
for region in "${regions[@]}"; do
  echo "Creating S3 bucket in region $region..."
  # Create a CloudFormation stack in the current region
  aws cloudformation create-stack --stack-name teststack --template-body file://labs1.3.1.yaml --region $region
done