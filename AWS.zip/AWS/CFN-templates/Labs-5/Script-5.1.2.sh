#!/bin/bash

stack="test-EC2-stack"

echo "Creating $stack..."

aws cloudformation create-stack --stack-name $stack --template-body file://CFN-labs5.1.2.yaml --region us-east-1

aws cloudformation wait stack-create-complete --stack-name $stack