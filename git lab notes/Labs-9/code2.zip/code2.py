import boto3
import json

def lambda_handler(event, context):
    db = boto3.client('dynamodb')

    db.put_item(TableName = 'tablelab09', Item = {'item': {'S': event['body']}})}